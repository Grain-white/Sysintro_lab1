#ifndef LOAD_H
#define LOAD_H

int load(const char* file);

#endif // LOAD_H
